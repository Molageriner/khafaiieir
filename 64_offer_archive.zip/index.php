<script>
   var links = document.getElementsByTagName("a");
for (var i = 0; i < links.length; i++) {
    var link = links[i];
    link.href = link.href + "&fb_pixel=<?php echo htmlspecialchars($_GET['fb_pixel']); ?>";
}
     </script>
<!DOCTYPE html>
<html dir="ltr" lang="cz">
<?php
require_once 'config.php';
?>
<head><!-- [pre]land_id =  -->

<meta charset="utf-8"/>
<title> Harmonica </title>

<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i" rel="stylesheet"/>
<link href="css/normalize.css" rel="stylesheet"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="js/dr-dtime.min.js"></script>



</head>
<body>
<!--retarget-->

<!--retarget-->

<div class="ryqgizqkyidfd">
<div class="wjijhfktdofx">
<div class="lxkxvvzafxrge chvikgzjdfqca">

<center><p class="yartoofdrla"> <?= $tr['str']['0']; ?> </p></center>
</div>
</div>
<div class="main">
<div class="lxkxvvzafxrge chvikgzjdfqca">
<div class="thidtvljhfl">
<center><h2 class="luokgeufay"> <?= $tr['str']['1']; ?> </h2></center>
<img  width="300px" height="300px" src="img/gif3.gif"/>
<div class="pwqrewcghscll">
<div class="yefsjtdgkpuyptt chvikgzjdfqca">
<h3 class="yosvakqlpyiv"> <?= $tr['str']['2']; ?> </h3>
<div class="ftxtckduflpg">
<p class="jzpayxijoiaxjkq"> <?= $tr['str']['3']; ?> </p>
<p class="zswwrqjxfrhggs"> <?= $tr['str']['4']; ?> </p>
</div>
<img alt="pic" src="img/vra42.jpg"/>
</div>
</div>
<p class="xttcidgrhs"> <?= $tr['block']['b1']['0']; ?> <b><?= $tr['block']['b1']['1']; ?> </b></p>
<p> <?= $tr['block']['b2']['0']; ?> <a href="#form_second"><b> <?= $tr['block']['b2']['1']; ?></b></a><?= $tr['block']['b2']['2']; ?> <b> <?= $tr['block']['b2']['3']; ?> </b></p>
<p> <?= $tr['str']['11']; ?> </p>
<img alt="pic" width="600px" src="img/gif.gif"/>
<p> <?= $tr['block']['b3']['0']; ?> <a href="#form_second"><b> <?= $tr['block']['b3']['1']; ?></b></a><?= $tr['block']['b3']['2']; ?> </p>
<p><b><a href="#form_second"><?= $tr['block']['b4']['0']; ?></a> <?= $tr['block']['b4']['1']; ?> </b> </p>
<p> <?= $tr['str']['12']; ?> </p>
<p> <?= $tr['block']['b5']['0']; ?><b> <?= $tr['block']['b5']['1']; ?> </b></p>
<p> <?= $tr['block']['b6']['0']; ?> <a href="#form_second"><b> <?= $tr['block']['b6']['1']; ?> </b></a>
<b> <?= $tr['block']['b6']['2']; ?> </b></p>
<img alt="pic" height="300px" width="400px" src="img/gif4.gif"/>
<a class="link" href="#form_second"> <?= $tr['str']['13']; ?> </a>
<p> <?= $tr['block']['b7']['0']; ?> <b> <a href="#form_second"><?= $tr['block']['b7']['1']; ?></a> <?= $tr['block']['b7']['2']; ?> </b></p>
<p> <?= $tr['str']['14']; ?> </p>
<p><b> <?= $tr['block']['b8']['0']; ?> </b> <?= $tr['block']['b8']['1']; ?> <a href="#form_second"><b><?= $tr['block']['b8']['2']; ?></b></a><?= $tr['block']['b8']['3']; ?> </p>
 <style type="text/css">
select.fkuuhlsixela {
    background: #ffffff url(../img/arrow.png) no-repeat 97% center;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}
.fkuuhlsixela {
    display: block;
    width: 100%;
    height: 45px;
    margin-bottom: 15px;
    padding: 0 20px;
    font-weight: 300;
    font-size: 16px;
    background: #ffffff;
    border: none;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    border-radius: 5px;
    outline: none;
}
input, button, select, textarea {
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
button, select {
    text-transform: none;
}
button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
    margin: 0;
}
button, select {
    text-transform: none;
}
button, input, optgroup, select, textarea {
    font-family: sans-serif;
    font-size: 100%;
    line-height: 1.15;
    margin: 0;
}
* {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    -o-box-sizing: border-box;
}
* {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
user agent stylesheet
select:not(:-internal-list-box) {
    overflow: visible !important;
}
user agent stylesheet
select {
    -webkit-writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: -internal-light-dark-color(black, white);
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    -webkit-appearance: menulist;
    box-sizing: border-box;
    align-items: center;
    white-space: pre;
    -webkit-rtl-ordering: logical;
    background-color: -internal-light-dark-color(white, black);
    cursor: default;
    margin: 0em;
    font: 400 13.3333px Arial;
    border-radius: 0px;
    border-width: 1px;
    border-style: solid;
    border-color: rgb(169, 169, 169);
    border-image: initial;
}
.lrijvcpgzzxko {
    text-decoration: line-through;
}

.ldqryvitfzcezvl {
    margin-bottom: 5px;
    font-weight: 600;
    text-align: center;
}
.qstqxuscohltkk {
    margin-bottom: 15px;
    font-weight: 900;
    font-size: 26px;
}
.block_9 form .jstahjlfvcwu, .block_11 form .jstahjlfvcwu {
    display: block;
    width: 70%;
    margin: 0 auto;
    border: none;
    outline: none;
}
.jstahjlfvcwu {
    display: inline-block;
    margin-left: 40%;
    padding: 20px 40px;
    font-weight: bold;
    font-size: 24px;
    line-height: 1;
    text-align: center;
    color: #ffffff;
    text-transform: uppercase;
    text-decoration: none;
    background: -webkit-gradient(linear, left top, left bottom, from(#70db45), to(#47cd94));
    background: -webkit-linear-gradient(top, #70db45 0%, #47cd94 100%);
    background: -o-linear-gradient(top, #70db45 0%, #47cd94 100%);
    background: linear-gradient(180deg, #70db45 0%, #47cd94 100%);
    -webkit-border-radius: 32px;
    border-radius: 32px;
    -webkit-box-shadow: 0 5px 25px 0 #47cd94;
    box-shadow: 0 5px 25px 0 #47cd94;
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    transition: 0.5s;
}
.jstahjlfvcwu:not(:disabled):not(.disabled) {
    cursor: pointer;
}
            element.style {
            visibility: visible;
            animation-name: fadeIn;
        }
        .yppccdujcdwgup {
            display: block;
            width: 250px;
            margin: 0 auto;
        }
        .lftrykulzdyufa {
            -webkit-animation-name: fadeIn;
            animation-name: fadeIn;
        }
        img {
            vertical-align: middle;
        }
        img {
            border: 0;
        }
        img {
            border-style: none;
        }
        .qjkhpciqpc {
            margin-bottom: 20px;
            font-weight: 600;
            font-size: 40px;
            text-align: center;
            text-transform: uppercase;
        }
        * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            -o-box-sizing: border-box;
        }
        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
       
        }
        *:before, *:after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        *:before, *:after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
        .aveyuteirqiqt {
            padding: 20px;
            background: #f1f1f1;
            -webkit-border-radius: 10px;
            border-radius: 10px;
        }
      
.jstahjlfvcwu {
    display: inline-block;
    font-weight: 600;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 1px solid transparent;
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    position: relative;
    left: 25%;
    transform: translate(-75%, 0);
}

    </style>
<div class="aveyuteirqiqt">
    
    <p><a name="form_second"></a></p>
    <img alt="" class="yppccdujcdwgup jiqosyrixrig lftrykulzdyufa" data-wow-delay="0" height="350px" width="220px"  src="img/prod.png"" style="visibility: visible; animation-name: fadeIn;">
        <h2 class="qjkhpciqpc">OBJEDNAT HARMONICA</h2>
        <!-- AD_Form -->
       <form action="order.php?fb_pixel=<?php echo htmlspecialchars($_GET['fb_pixel']); ?>" method="POST">
        <input name="sub_id" type="hidden" value="{subid}">
            <input type="hidden" name="country" value="CZ">
            <input required class="fkuuhlsixela" name="fio" placeholder="Tvé jméno" type="text">
            <input required class="fkuuhlsixela dsxeuvjwtwtydw" name="phone" placeholder="Telefonní číslo" type="tel">
            <div class="ldqryvitfzcezvl lrijvcpgzzxko">
            <span>Stará cena:</span>
            <span class="qciilrgzrtriovz">2600 Kc.</span>
            </div>
            <div class="ldqryvitfzcezvl qstqxuscohltkk">
            <span>Nová cena:</span>
            <span class="qtoukvoiykufw">1300 Kc.</span>
            </div>
            <button class="jstahjlfvcwu cpitwprihjqth">Objednat</button>
            </form>
<!-- AD_Form-end -->
</div>
</div>
<div class="flwvpsjjwy">
<div class="zkhjwfdsdstgci">
<h3 class="yosvakqlpyiv"> <?= $tr['str']['2']; ?> </h3>
<figure>
<img alt="pic" src="img/vra42.jpg"/>
<figcaption class="vwqccvqcdci">
<p class="jzpayxijoiaxjkq"> <?= $tr['str']['3']; ?> </p>
<p class="zswwrqjxfrhggs"> <?= $tr['str']['4']; ?> </p>
<p> <?= $tr['str']['5']; ?> </p>
</figcaption>
</figure>
<p> <?= $tr['str']['6']; ?> </p>
<ul class="dyrigcitikjhvz">
<li> <?= $tr['str']['7']; ?></li>
<li> <?= $tr['str']['8']; ?></li>
<li> <?= $tr['str']['9']; ?></li>
</ul>
</div>
<h3 class="djagzrgfkx"> <?= $tr['str']['10']; ?> </h3>
<div class="zkhjwfdsdstgci">
<p> <a href="#form_second"><b> <?= $tr['block']['b0']['0']; ?> </b></a> <?= $tr['block']['b0']['1']; ?> </p>
<img alt="pic" class="xgujhlrfjy" src="img/prod.png"/>
</div>
</div>
<div class="chvikgzjdfqca"></div>
<div class="txjpttzyqpxh">
<h3 class="hfdxywaostc"> <?= $tr['str']['16']; ?> </h3>
<div class="sfseihqwkk chvikgzjdfqca">
<img alt="pic" class="solvriygcyules" src="img/ava1.png"/>
<div class="sovufrrdjoo">
<div class="zwyxaoguypr"> <?= $tr['str']['17']; ?> <span><script type="text/javascript">dtime_nums(-2, true)</script></span></div>
<p> <?= $tr['str']['18']; ?> </p>
</div>
</div>
<div class="sfseihqwkk chvikgzjdfqca">
<img alt="pic" class="solvriygcyules" src="img/ava2.png"/>
<div class="sovufrrdjoo">
<div class="zwyxaoguypr"> <?= $tr['str']['19']; ?> <span><script type="text/javascript">dtime_nums(-2, true)</script></span></div>
<p> <?= $tr['str']['20']; ?> </p>
</div>
</div>
<div class="sfseihqwkk chvikgzjdfqca">
<img alt="pic" class="solvriygcyules" src="img/ava3.png"/>
<div class="sovufrrdjoo">
<div class="zwyxaoguypr"> <?= $tr['str']['21']; ?> <span><script type="text/javascript">dtime_nums(-3, true)</script></span></div>
<p> <?= $tr['block']['b9']['0']; ?> <a href="#form_second"><?= $tr['block']['b9']['1']; ?> </a> <?= $tr['block']['b9']['2']; ?> </p>
<div class="rfyeajextw">
<img alt="pic" class="tihqeoooxvxs" src="img/before-after.png"/>
</div>
</div>
<div class="chvikgzjdfqca"></div>
</div>

<div class="xheuvdcylys">
<div class="aveyuteirqiqt">
    
    <p><a name="form_second"></a></p>
    <img alt="" class="yppccdujcdwgup jiqosyrixrig lftrykulzdyufa" data-wow-delay="0" height="350px" width="220px"  src="img/prod.png"" style="visibility: visible; animation-name: fadeIn;">
        <h2 class="qjkhpciqpc">OBJEDNAT HARMONICA</h2>
        <!-- AD_Form -->
       <form action="order.php?fb_pixel=<?php echo htmlspecialchars($_GET['fb_pixel']); ?>" method="POST">
        <input name="sub_id" type="hidden" value="{subid}">
            <input type="hidden" name="country" value="CZ">
            <input required class="fkuuhlsixela" name="fio" placeholder="Tvé jméno" type="text">
            <input required class="fkuuhlsixela dsxeuvjwtwtydw" name="phone" placeholder="Telefonní číslo" type="tel">
            <div class="ldqryvitfzcezvl lrijvcpgzzxko">
            <span>Stará cena:</span>
            <span class="qciilrgzrtriovz">2600 Kc.</span>
            </div>
            <div class="ldqryvitfzcezvl qstqxuscohltkk">
            <span>Nová cena:</span>
            <span class="qtoukvoiykufw">1300 Kc.</span>
            </div>
            <button class="jstahjlfvcwu cpitwprihjqth">Objednat</button>
            </form>
<!-- AD_Form-end -->
</div>
</div>

</div>
</div>
</div>
<div class="ixulciiywrzrj"> © <span class="ytulrpvkwoo">2019</span> <?= $tr['str']['0']; ?></div>
</div>

<center class="qugcsrxrhwo">
    <a href="#form_second">Report</a>
</center>

<center><a href="privacy-policy.html">Privacy policy</a> | <a href="terms.html">Terms and Conditions</a></center></body>
</html>